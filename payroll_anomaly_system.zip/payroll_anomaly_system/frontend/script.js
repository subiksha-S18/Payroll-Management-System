
/* =========================================
   API URLS
========================================= */

const API_URL = "http://127.0.0.1:8000/api/employees/dashboard/";
const EMPLOYEE_API = "http://127.0.0.1:8000/api/employees/";
const HISTORY_API = "http://127.0.0.1:8000/api/employees/salary-history/";
const ANOMALY_API = "http://127.0.0.1:8000/api/employees/salary-anomalies/";

let allEmployees = [];


/* =========================================
   HELPER FUNCTIONS
========================================= */

function formatCurrency(amount) {
    return "₹" + Number(amount || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

async function getJSON(url, options = {}) {

    const response = await fetch(url, {
        credentials: "same-origin",
        ...options
    });

    const text = await response.text();

    let data = {};

    try {
        data = text ? JSON.parse(text) : {};
    } catch {
        throw new Error("Invalid server response.");
    }

    if (!response.ok) {
        throw new Error(
            data.error || data.message || `Request failed (${response.status})`
        );
    }

    return data;
}

function showMessage(id, message, color) {
    const element = document.getElementById(id);
    element.textContent = message;
    element.style.color = color;
}

function addText(parent, tag, label, value) {
    const element = document.createElement(tag);
    element.textContent = label + (value ?? "");
    parent.appendChild(element);
}


/* =========================================
   SIDEBAR NAVIGATION
========================================= */

document.querySelectorAll(".nav-btn").forEach(button => {

    button.addEventListener("click", function () {

        const targetId = this.dataset.section;

        document.querySelectorAll(".page-section").forEach(section => {
            section.classList.remove("active");
        });

        document.querySelectorAll(".nav-btn").forEach(btn => {
            btn.classList.remove("active");
        });

        const targetSection = document.getElementById(targetId);

        if (targetSection) {
            targetSection.classList.add("active");
        }

        this.classList.add("active");

    });

});


/* =========================================
   PAGE LOAD
========================================= */

document.addEventListener("DOMContentLoaded", function () {

    document.getElementById("employeeForm")
        .addEventListener("submit", addEmployee);

    document.getElementById("salaryForm")
        .addEventListener("submit", updateSalary);

    document.getElementById("employeeSearch")
        .addEventListener("input", filterEmployees);

    document.getElementById("departmentFilter")
        .addEventListener("change", filterEmployees);

    refreshAllData();

});


/* =========================================
   REFRESH ALL DATA
========================================= */

async function refreshAllData() {

    await Promise.allSettled([
        loadDashboard(),
        loadEmployees(),
        loadSalaryHistory(),
        loadSalaryAlerts(),
        loadAnomalies()
    ]);

}


/* =========================================
   DASHBOARD
========================================= */

async function loadDashboard() {

    try {

        const data = await getJSON(API_URL);

        document.getElementById("totalEmployees").textContent =
            data.total_employees ?? 0;

        document.getElementById("totalPayroll").textContent =
            formatCurrency(data.total_payroll);

        document.getElementById("salaryIncreases").textContent =
            data.salary_increases ?? 0;

        document.getElementById("promotions").textContent =
            data.promotions ?? 0;

        document.getElementById("pendingReviews").textContent =
            data.pending_reviews ?? 0;

        document.getElementById("approvedReviews").textContent =
            data.approved_reviews ?? 0;

        document.getElementById("rejectedReviews").textContent =
            data.rejected_reviews ?? 0;

    } catch (error) {
        console.error("Dashboard error:", error);
    }

}


/* =========================================
   ADD EMPLOYEE
========================================= */

async function addEmployee(event) {

    event.preventDefault();

    const employee = {

        employee_id: document.getElementById("employeeId").value.trim(),

        name: document.getElementById("employeeName").value.trim(),

        department: document.getElementById("department").value.trim(),

        designation: document.getElementById("designation").value.trim(),

        salary: document.getElementById("salary").value,

        join_date: document.getElementById("joinDate").value,

        promotion: document.getElementById("promotion").checked

    };

    try {

        await getJSON(EMPLOYEE_API, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(employee)

        });

        showMessage(
            "employeeMessage",
            "Employee added successfully!",
            "green"
        );

        document.getElementById("employeeForm").reset();

        await refreshAllData();

    } catch (error) {

        console.error("Add employee error:", error);

        showMessage("employeeMessage", error.message, "red");

    }

}


/* =========================================
   LOAD EMPLOYEES
========================================= */

async function loadEmployees() {

    try {

        const data = await getJSON(EMPLOYEE_API);

        allEmployees = Array.isArray(data)
            ? data
            : data.employees || [];

        updateDepartmentFilter();

        displayEmployees(allEmployees);

    } catch (error) {

        console.error("Employee loading error:", error);

    }

}


/* =========================================
   DEPARTMENT FILTER
========================================= */

function updateDepartmentFilter() {

    const filter = document.getElementById("departmentFilter");

    const currentValue = filter.value;

    const departments = [
        ...new Set(
            allEmployees.map(employee => employee.department).filter(Boolean)
        )
    ];

    filter.innerHTML = '<option value="all">All Departments</option>';

    departments.forEach(department => {

        const option = document.createElement("option");

        option.value = department;
        option.textContent = department;

        filter.appendChild(option);

    });

    filter.value = departments.includes(currentValue)
        ? currentValue
        : "all";

}


/* =========================================
   DISPLAY EMPLOYEES
========================================= */

function displayEmployees(employees) {

    const container = document.getElementById("employeeList");

    container.innerHTML = "";

    if (!employees.length) {
        container.textContent = "No employees found.";
        return;
    }

    employees.forEach(employee => {

        const card = document.createElement("div");

        card.className = "employee-card";

        const heading = document.createElement("h3");

        heading.textContent =
            `${employee.name} (${employee.employee_id})`;

        card.appendChild(heading);

        addText(card, "p", "Department: ", employee.department);
        addText(card, "p", "Designation: ", employee.designation);
        addText(card, "p", "Salary: ", formatCurrency(employee.salary));
        addText(card, "p", "Join Date: ", employee.join_date);
        addText(
            card,
            "p",
            "Promotion: ",
            employee.promotion ? "Yes" : "No"
        );

        container.appendChild(card);

    });

}


/* =========================================
   SEARCH AND FILTER
========================================= */

function filterEmployees() {

    const searchText = document.getElementById("employeeSearch")
        .value.toLowerCase().trim();

    const department = document.getElementById("departmentFilter").value;

    const filtered = allEmployees.filter(employee => {

        const name = String(employee.name || "").toLowerCase();

        const id = String(employee.employee_id || "").toLowerCase();

        const matchesSearch =
            name.includes(searchText) || id.includes(searchText);

        const matchesDepartment =
            department === "all" || employee.department === department;

        return matchesSearch && matchesDepartment;

    });

    displayEmployees(filtered);

}


/* =========================================
   UPDATE SALARY
========================================= */

async function updateSalary(event) {

    event.preventDefault();

    const employeeId = document.getElementById("updateEmployeeId")
        .value.trim();

    const salary = document.getElementById("newSalary").value;

    const promotion = document.getElementById("updatePromotion")
        .value === "true";

    const designation = document.getElementById("newDesignation")
        .value.trim();

    if (!employeeId || !salary || Number(salary) <= 0) {

        showMessage(
            "salaryMessage",
            "Enter a valid Employee ID and salary.",
            "red"
        );

        return;

    }

    try {

        const data = await getJSON(
            EMPLOYEE_API + encodeURIComponent(employeeId) + "/",
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    salary: salary,
                    promotion: promotion,
                    designation: designation
                })
            }
        );

        if (data.pending_approval) {

            showMessage(
                "salaryMessage",
                `Salary anomaly detected! Waiting for HR approval.
Proposed Salary: ${formatCurrency(data.proposed_salary)}
Risk: ${data.risk_level}
HR Email: ${data.email_sent ? "Sent" : "Not Sent"}`,
                "orange"
            );

        } else {

            showMessage(
                "salaryMessage",
                data.message || "Employee salary updated successfully!",
                "green"
            );

        }

        document.getElementById("salaryForm").reset();

        await refreshAllData();

    } catch (error) {

        console.error("Salary update error:", error);

        showMessage("salaryMessage", error.message, "red");

    }

}


/* =========================================
   SALARY ALERTS
========================================= */

async function loadSalaryAlerts() {

    try {

        const data = await getJSON(API_URL);

        const container = document.getElementById("salaryAlerts");

        container.innerHTML = "";

        const alerts = data.alerts || [];

        if (!alerts.length) {
            container.textContent = "No salary alerts available.";
            return;
        }

        alerts.forEach(alert => {

            const card = document.createElement("div");

            card.className = "alert-card";

            const heading = document.createElement("h3");

            heading.textContent =
                `${alert.name} (${alert.employee_id})`;

            card.appendChild(heading);

            addText(card, "p", "Designation: ", alert.designation);
            addText(card, "p", "Salary: ", formatCurrency(alert.salary));
            addText(card, "p", "Increase: ", formatCurrency(alert.salary_increase));
            addText(card, "p", "Alert: ", alert.alert_message);

            container.appendChild(card);

        });

    } catch (error) {

        console.error("Salary alerts error:", error);

    }

}


/* =========================================
   SALARY ANOMALY ALERTS
========================================= */

async function loadAnomalies() {

    try {

        const data = await getJSON(ANOMALY_API);

        const container = document.getElementById("anomalyAlerts");

        container.innerHTML = "";

        const anomalies = data.anomalies || [];

        if (!anomalies.length) {
            container.textContent = "No salary anomalies detected.";
            return;
        }

        anomalies.forEach(anomaly => {

            const card = document.createElement("div");

            card.className = "anomaly-card";

            const heading = document.createElement("h3");

            heading.textContent =
                `⚠️ ${anomaly.name} (${anomaly.employee_id})`;

            card.appendChild(heading);

            addText(card, "p", "Old Salary: ",
                formatCurrency(anomaly.old_salary));

            addText(card, "p", "Proposed Salary: ",
                formatCurrency(anomaly.new_salary));

            addText(card, "p", "Increase: ",
                formatCurrency(anomaly.salary_increase));

            addText(card, "p", "Increase Percentage: ",
                `${anomaly.increase_percentage}%`);

            addText(card, "p", "Risk Level: ", anomaly.risk_level);

            addText(card, "p", "Reason: ", anomaly.reason);

            addText(card, "p", "HR Status: ", anomaly.review_status);

            addText(
                card,
                "p",
                "Email Status: ",
                anomaly.email_sent ? "Sent" : "Not Sent"
            );

            container.appendChild(card);

        });

    } catch (error) {

        console.error("Anomaly loading error:", error);

    }

}


/* =========================================
   SALARY HISTORY
========================================= */

async function loadSalaryHistory() {

    try {

        const history = await getJSON(HISTORY_API);

        const container = document.getElementById("salaryHistory");

        container.innerHTML = "";

        const records = Array.isArray(history)
            ? history
            : history.history || [];

        if (!records.length) {
            container.textContent = "No salary history available.";
            return;
        }

        records.forEach(record => {

            const card = document.createElement("div");

            card.className = "history-card";

            const heading = document.createElement("h3");

            heading.textContent =
                `${record.name} (${record.employee_id})`;

            card.appendChild(heading);

            addText(card, "p", "Old Salary: ",
                formatCurrency(record.old_salary));

            addText(card, "p", "New Salary: ",
                formatCurrency(record.new_salary));

            addText(card, "p", "Increase: ",
                formatCurrency(record.salary_increase));

            addText(
                card,
                "p",
                "Promotion: ",
                record.promotion ? "Yes" : "No"
            );

            addText(card, "p", "Changed At: ", record.changed_at);

            container.appendChild(card);

        });

    } catch (error) {

        console.error("Salary history error:", error);

    }

}
