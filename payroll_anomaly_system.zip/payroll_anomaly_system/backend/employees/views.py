
import json
from decimal import Decimal, InvalidOperation

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Sum
from django.db import transaction
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail

from .models import (
    Employee,
    SalaryHistory,
    AnomalyReview,
    SalaryVerification
)

from .anomaly import detect_salary_anomaly


# =========================================
# FINANCE MANAGER EMAIL
# =========================================

def send_verification_email(verification):

    subject = "Salary Verification Required - Payroll System"

    message = f"""
Dear HR,

An unusual salary change has been detected.

Employee ID: {verification.employee.employee_id}
Employee Name: {verification.employee.name}

Previous Salary: ₹{verification.old_salary}
Proposed Salary: ₹{verification.proposed_salary}

Increase Percentage: {verification.increase_percentage}%

Risk Level: {verification.risk_level}

Reason: {verification.reason}

Please login to the Payroll Management System
and review this salary change.

Regards,
Payroll Management System
"""

    try:
        email_count = send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [settings.FINANCE_EMAIL],
            fail_silently=False
        )

        return email_count > 0

    except Exception as e:
        print("Finance email failed:", e)
        return False


# =========================================
# EMPLOYEE LIST + ADD EMPLOYEE
# =========================================

@csrf_exempt
def employee_list(request):

    if request.method == "GET":

        employees = Employee.objects.all().order_by("employee_id")

        data = []

        for employee in employees:

            data.append({
                "employee_id": employee.employee_id,
                "name": employee.name,
                "department": employee.department,
                "designation": employee.designation,
                "salary": float(employee.salary),
                "join_date": str(employee.join_date),
                "promotion": employee.promotion,
                "salary_increase": float(employee.salary_increase),
                "alert_message": employee.alert_message
            })

        return JsonResponse(data, safe=False)

    if request.method == "POST":

        try:
            body = json.loads(request.body)

            employee = Employee.objects.create(
                employee_id=body["employee_id"],
                name=body["name"],
                department=body["department"],
                designation=body["designation"],
                salary=Decimal(str(body["salary"])),
                join_date=body["join_date"],
                promotion=body.get("promotion", False)
            )

            return JsonResponse({
                "message": "Employee created successfully",
                "employee_id": employee.employee_id
            }, status=201)

        except (KeyError, InvalidOperation, ValueError) as e:
            return JsonResponse({"error": str(e)}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return JsonResponse(
        {"error": "Method not allowed"},
        status=405
    )


# =========================================
# UPDATE EMPLOYEE SALARY
# =========================================

@csrf_exempt
def update_employee(request, employee_id):

    if request.method != "PUT":
        return JsonResponse(
            {"error": "Method not allowed"},
            status=405
        )

    try:
        employee = Employee.objects.get(employee_id=employee_id)
        body = json.loads(request.body)

        old_salary = employee.salary

        new_salary = Decimal(
            str(body.get("salary", old_salary))
        )

        new_promotion = body.get(
            "promotion",
            employee.promotion
        )

        new_designation = body.get(
            "designation",
            employee.designation
        )

        if new_salary <= 0:
            return JsonResponse(
                {"error": "Salary must be greater than zero"},
                status=400
            )

        result = detect_salary_anomaly(
            old_salary=old_salary,
            new_salary=new_salary,
            promotion=new_promotion
        )

        # ANOMALY FOUND

        if result["is_anomaly"]:

            percentage = Decimal(
                str(result["increase_percentage"])
            )

            verification = SalaryVerification.objects.create(
                employee=employee,
                old_salary=old_salary,
                proposed_salary=new_salary,
                increase_percentage=percentage,
                risk_level=result["risk_level"],
                reason=result["reason"],
                status="Pending"
            )

            email_sent = send_verification_email(verification)

            return JsonResponse({
                "message": (
                    "Unusual salary change detected. "
                    "Waiting for Finance Manager verification."
                ),
                "pending_approval": True,
                "employee_id": employee.employee_id,
                "current_salary": float(old_salary),
                "proposed_salary": float(new_salary),
                "risk_level": verification.risk_level,
                "increase_percentage": float(percentage),
                "verification_id": verification.id,
                "review_id": verification.id,
                "review_status": verification.status,
                "email_sent": email_sent
            }, status=202)

        # NORMAL SALARY UPDATE

        with transaction.atomic():

            SalaryHistory.objects.create(
                employee=employee,
                old_salary=old_salary,
                new_salary=new_salary,
                salary_increase=new_salary - old_salary,
                promotion=new_promotion
            )

            employee.salary = new_salary
            employee.promotion = new_promotion
            employee.designation = new_designation
            employee.salary_increase = new_salary - old_salary
            employee.save()

        return JsonResponse({
            "message": "Employee updated successfully",
            "pending_approval": False,
            "employee_id": employee.employee_id,
            "salary": float(employee.salary),
            "promotion": employee.promotion,
            "designation": employee.designation
        })

    except Employee.DoesNotExist:
        return JsonResponse(
            {"error": "Employee not found"},
            status=404
        )

    except (InvalidOperation, ValueError, TypeError) as e:
        return JsonResponse({"error": str(e)}, status=400)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)


# =========================================
# SALARY HISTORY
# =========================================

def salary_history(request):

    if request.method != "GET":
        return JsonResponse(
            {"error": "Method not allowed"},
            status=405
        )

    history = SalaryHistory.objects.select_related(
        "employee"
    ).order_by("-changed_at")

    data = []

    for record in history:

        data.append({
            "employee_id": record.employee.employee_id,
            "name": record.employee.name,
            "old_salary": float(record.old_salary),
            "new_salary": float(record.new_salary),
            "salary_increase": float(record.salary_increase),
            "promotion": record.promotion,
            "changed_at": record.changed_at.strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        })

    return JsonResponse(data, safe=False)


# =========================================
# DASHBOARD SUMMARY
# =========================================

def dashboard(request):

    if request.method != "GET":
        return JsonResponse(
            {"error": "Method not allowed"},
            status=405
        )

    total_employees = Employee.objects.count()

    total_payroll = Employee.objects.aggregate(
        total=Sum("salary")
    )["total"] or 0

    salary_increases = Employee.objects.filter(
        salary_increase__gt=0
    ).count()

    promotions = Employee.objects.filter(
        promotion=True
    ).count()

    pending_reviews = SalaryVerification.objects.filter(
        status="Pending"
    ).count()

    approved_reviews = SalaryVerification.objects.filter(
        status="Approved"
    ).count()

    rejected_reviews = SalaryVerification.objects.filter(
        status="Rejected"
    ).count()

    alerts = Employee.objects.exclude(
        alert_message__isnull=True
    ).exclude(
        alert_message=""
    ).values(
        "employee_id",
        "name",
        "designation",
        "salary",
        "salary_increase",
        "alert_message"
    )

    return JsonResponse({
        "total_employees": total_employees,
        "total_payroll": float(total_payroll),
        "salary_increases": salary_increases,
        "promotions": promotions,
        "pending_reviews": pending_reviews,
        "approved_reviews": approved_reviews,
        "rejected_reviews": rejected_reviews,
        "alerts": list(alerts)
    })


# =========================================
# SALARY ANOMALY DETECTION
# =========================================

def salary_anomalies(request):

    if request.method != "GET":
        return JsonResponse(
            {"error": "Method not allowed"},
            status=405
        )

    verifications = SalaryVerification.objects.select_related(
        "employee"
    ).order_by("-created_at")

    anomalies = []

    for verification in verifications:

        anomalies.append({
            "employee_id": verification.employee.employee_id,
            "name": verification.employee.name,
            "old_salary": float(verification.old_salary),
            "new_salary": float(verification.proposed_salary),
            "salary_increase": float(
                verification.proposed_salary - verification.old_salary
            ),
            "increase_percentage": float(
                verification.increase_percentage
            ),
            "risk_level": verification.risk_level,
            "reason": verification.reason,
            "changed_at": verification.created_at.strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "review_id": verification.id,
            "verification_id": verification.id,
            "review_status": verification.status
        })

    return JsonResponse({
        "total_anomalies": len(anomalies),
        "anomalies": anomalies
    })


# =========================================
# FINANCE MANAGER VERIFICATION
# LOGIN PROTECTED
# =========================================

@csrf_exempt
def anomaly_reviews(request):

    if not request.user.is_authenticated or not (
        request.user.is_staff or request.user.is_superuser
    ):
        return JsonResponse(
            {"error": "Finance Manager login required"},
            status=403
        )

    # GET VERIFICATION REQUESTS

    if request.method == "GET":

        verifications = SalaryVerification.objects.select_related(
            "employee"
        ).order_by("-created_at")

        data = []

        for verification in verifications:

            data.append({
                "id": verification.id,
                "review_id": verification.id,
                "employee_id": verification.employee.employee_id,
                "name": verification.employee.name,
                "old_salary": float(verification.old_salary),
                "new_salary": float(verification.proposed_salary),
                "salary_increase": float(
                    verification.proposed_salary - verification.old_salary
                ),
                "increase_percentage": float(
                    verification.increase_percentage
                ),
                "risk_level": verification.risk_level,
                "reason": verification.reason,
                "status": verification.status,
                "email_sent": True,
                "created_at": verification.created_at.strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),
                "reviewed_at": (
                    verification.reviewed_at.strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                    if verification.reviewed_at else None
                )
            })

        return JsonResponse(data, safe=False)

    # APPROVE / REJECT REQUEST

    if request.method == "PUT":

        try:
            body = json.loads(request.body)

            verification_id = body.get(
                "verification_id",
                body.get("review_id")
            )

            status = body["status"]

            if status not in ["Approved", "Rejected"]:
                return JsonResponse(
                    {"error": "Status must be Approved or Rejected"},
                    status=400
                )

            with transaction.atomic():

                verification = (
                    SalaryVerification.objects
                    .select_for_update()
                    .select_related("employee")
                    .get(id=verification_id)
                )

                if verification.status != "Pending":
                    return JsonResponse({
                        "error": "This request has already been processed",
                        "current_status": verification.status
                    }, status=400)

                employee = verification.employee

                if status == "Approved":

                    if employee.salary != verification.old_salary:
                        return JsonResponse({
                            "error": (
                                "Employee salary has changed since this request "
                                "was created. Please review again."
                            )
                        }, status=409)

                    SalaryHistory.objects.create(
                        employee=employee,
                        old_salary=verification.old_salary,
                        new_salary=verification.proposed_salary,
                        salary_increase=(
                            verification.proposed_salary -
                            verification.old_salary
                        ),
                        promotion=employee.promotion
                    )

                    employee.salary = verification.proposed_salary

                    employee.salary_increase = (
                        verification.proposed_salary -
                        verification.old_salary
                    )

                    employee.alert_message = (
                        "Salary change verified and approved by Finance Manager."
                    )

                    employee.save()

                # Rejection keeps previous salary unchanged

                verification.status = status
                verification.reviewed_at = timezone.now()
                verification.reviewer = request.user

                verification.save(update_fields=[
                    "status",
                    "reviewed_at",
                    "reviewer"
                ])

            employee.refresh_from_db()

            return JsonResponse({
                "message": (
                    "Salary approved and updated successfully"
                    if status == "Approved"
                    else "Salary rejected. Previous salary remains unchanged."
                ),
                "verification_id": verification.id,
                "review_id": verification.id,
                "status": verification.status,
                "employee_id": employee.employee_id,
                "employee_name": employee.name,
                "current_salary": float(employee.salary),
                "reviewed_at": verification.reviewed_at.strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
            })

        except SalaryVerification.DoesNotExist:
            return JsonResponse(
                {"error": "Verification request not found"},
                status=404
            )

        except (KeyError, ValueError, TypeError) as e:
            return JsonResponse({"error": str(e)}, status=400)

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return JsonResponse(
        {"error": "Method not allowed"},
        status=405
    )
