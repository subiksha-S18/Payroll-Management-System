
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import user_passes_test
from django.views.decorators.http import require_POST


def hr_login(request):
    if request.user.is_authenticated and (
        request.user.is_staff or request.user.is_superuser
    ):
        return redirect('hr-dashboard')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None and (
            user.is_staff or user.is_superuser
        ):
            login(request, user)
            return redirect('hr-dashboard')

        messages.error(
            request,
            'Invalid HR username or password.'
        )

    return render(request, 'employees/hr_login.html')


def is_hr(user):
    return user.is_authenticated and (
        user.is_staff or user.is_superuser
    )


@user_passes_test(is_hr, login_url='hr-login')
def hr_dashboard(request):
    return render(request, 'employees/hr_dashboard.html')


@require_POST
def hr_logout(request):
    logout(request)
    return redirect('hr-login')
