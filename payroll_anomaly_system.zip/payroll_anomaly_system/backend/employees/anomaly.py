from decimal import Decimal


def detect_salary_anomaly(
    old_salary,
    new_salary,
    promotion=False
):
    old_salary = Decimal(str(old_salary))
    new_salary = Decimal(str(new_salary))

    # Invalid salary
    if new_salary <= 0:
        return {
            "is_anomaly": True,
            "risk_level": "High",
            "reason": "Invalid or unusually low salary amount.",
            "increase_percentage": 0
        }

    if old_salary <= 0:
        return {
            "is_anomaly": True,
            "risk_level": "High",
            "reason": "Previous salary is invalid.",
            "increase_percentage": 0
        }

    increase_percentage = (
        (new_salary - old_salary) / old_salary
    ) * 100

    increase_percentage = round(increase_percentage, 2)

    # Salary decrease above 30%
    if increase_percentage < -30:
        return {
            "is_anomaly": True,
            "risk_level": "High",
            "reason": "Salary decreased by more than 30%.",
            "increase_percentage": float(increase_percentage)
        }

    # Promotion with normal increase
    if promotion and increase_percentage <= 30 and increase_percentage >= 0:
        return {
            "is_anomaly": False,
            "risk_level": "Low",
            "reason": "Salary increase is within normal promotion range.",
            "increase_percentage": float(increase_percentage)
        }

    # Salary increase above 50%
    if increase_percentage > 50:
        return {
            "is_anomaly": True,
            "risk_level": "High",
            "reason": "Salary increased by more than 50%.",
            "increase_percentage": float(increase_percentage)
        }

    # Salary increase above 30%
    if increase_percentage > 30:
        return {
            "is_anomaly": True,
            "risk_level": "Medium",
            "reason": "Salary increase is unusually high.",
            "increase_percentage": float(increase_percentage)
        }

    return {
        "is_anomaly": False,
        "risk_level": "Low",
        "reason": "Salary change is within normal range.",
        "increase_percentage": float(increase_percentage)
    }