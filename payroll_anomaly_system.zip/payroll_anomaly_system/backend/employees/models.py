from django.db import models


class Employee(models.Model):

    employee_id = models.CharField(
        max_length=20,
        unique=True
    )

    name = models.CharField(
        max_length=100
    )

    department = models.CharField(
        max_length=100
    )

    designation = models.CharField(
        max_length=100
    )

    salary = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    join_date = models.DateField()

    previous_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0
    )

    promotion = models.BooleanField(
        default=False
    )

    salary_increase = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=0
    )

    alert_message = models.TextField(
        blank=True,
        null=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )


    def save(self, *args, **kwargs):

        old_salary = None

        if self.pk:

            old_employee = Employee.objects.get(
                pk=self.pk
            )

            old_salary = old_employee.salary


            if self.salary > old_salary:

                self.previous_salary = old_salary

                self.salary_increase = (
                    self.salary - old_salary
                )


                if self.promotion:

                    self.alert_message = (
                        f"Salary increased from "
                        f"₹{old_salary} "
                        f"to ₹{self.salary} "
                        f"due to promotion."
                    )

                else:

                    self.alert_message = (
                        f"Salary increased from "
                        f"₹{old_salary} "
                        f"to ₹{self.salary}."
                    )


        super().save(*args, **kwargs)


        if (
            old_salary is not None
            and self.salary > old_salary
        ):

            SalaryHistory.objects.create(

                employee=self,

                old_salary=old_salary,

                new_salary=self.salary,

                salary_increase=(
                    self.salary - old_salary
                ),

                promotion=self.promotion

            )


    def __str__(self):

        return (
            f"{self.employee_id} - "
            f"{self.name}"
        )



class SalaryHistory(models.Model):

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name="salary_history"
    )

    old_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    new_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    salary_increase = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    promotion = models.BooleanField(
        default=False
    )

    changed_at = models.DateTimeField(
        auto_now_add=True
    )


    def __str__(self):

        return (
            f"{self.employee.employee_id} - "
            f"₹{self.old_salary} to "
            f"₹{self.new_salary}"
        )



class AnomalyReview(models.Model):

    STATUS_CHOICES = [

        ("Pending", "Pending"),

        ("Approved", "Approved"),

        ("Rejected", "Rejected"),

    ]


    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name="anomaly_reviews"
    )

    salary_history = models.ForeignKey(
        SalaryHistory,
        on_delete=models.CASCADE,
        related_name="anomaly_reviews"
    )

    risk_level = models.CharField(
        max_length=20
    )

    reason = models.TextField()
    email_sent = models.BooleanField(
    default=True
)


    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="Pending"
    )


    reviewed_at = models.DateTimeField(
        null=True,
        blank=True
    )


    created_at = models.DateTimeField(
        auto_now_add=True
    )


    def __str__(self):

        return (
            f"{self.employee.employee_id} - "
            f"{self.risk_level} - "
            f"{self.status}"
        )
        
class SalaryVerification(models.Model):

    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]

    RISK_CHOICES = [
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High'),
    ]

    employee = models.ForeignKey(
        Employee,
        on_delete=models.CASCADE,
        related_name='salary_verifications'
    )

    old_salary = models.DecimalField(max_digits=12, decimal_places=2)
    proposed_salary = models.DecimalField(max_digits=12, decimal_places=2)

    increase_percentage = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        default=0
    )

    risk_level = models.CharField(
        max_length=10,
        choices=RISK_CHOICES,
        default='Low'
    )

    reason = models.TextField(blank=True)

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='Pending'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)

    reviewer = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    def __str__(self):
        return f"{self.employee} - {self.status}"
