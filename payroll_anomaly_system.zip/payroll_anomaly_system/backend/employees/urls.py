
from django.urls import path

from .views import (
    employee_list,
    update_employee,
    dashboard,
    salary_history,
    salary_anomalies,
    anomaly_reviews
)

from .hr_views import (
    hr_login,
    hr_dashboard,
    hr_logout
)

urlpatterns = [
    # HR pages
    path('hr-login/', hr_login, name='hr-login'),
    path('hr-dashboard/', hr_dashboard, name='hr-dashboard'),
    path('hr-logout/', hr_logout, name='hr-logout'),

    # Existing employee APIs
    path('dashboard/', dashboard, name='dashboard'),
    path('salary-history/', salary_history, name='salary-history'),
    path('salary-anomalies/', salary_anomalies, name='salary-anomalies'),
    path('anomaly-reviews/', anomaly_reviews, name='anomaly-reviews'),
    path('', employee_list, name='employee-list'),
    path('<str:employee_id>/', update_employee, name='update-employee'),
]
