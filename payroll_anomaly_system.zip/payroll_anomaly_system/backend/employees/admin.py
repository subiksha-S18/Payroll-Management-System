
from django.contrib import admin
from .models import Employee, SalaryHistory, SalaryVerification


@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):

    list_display = (
        'employee_id',
        'name',
        'department',
        'designation',
        'salary',
        'promotion',
        'salary_increase',
        'alert_message',
        'created_at',
    )

    search_fields = (
        'employee_id',
        'name',
        'department',
        'designation',
    )

    list_filter = (
        'department',
        'promotion',
    )


@admin.register(SalaryHistory)
class SalaryHistoryAdmin(admin.ModelAdmin):

    list_display = (
        'employee',
        'old_salary',
        'new_salary',
        'salary_increase',
        'promotion',
        'changed_at',
    )

    list_filter = (
        'promotion',
        'changed_at',
    )


@admin.register(SalaryVerification)
class SalaryVerificationAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'employee',
        'old_salary',
        'proposed_salary',
        'increase_percentage',
        'risk_level',
        'status',
        'created_at',
    )

    list_filter = ('risk_level', 'status', 'created_at')

    search_fields = ('employee__name', 'employee__employee_id')

    readonly_fields = ('created_at', 'reviewed_at')
